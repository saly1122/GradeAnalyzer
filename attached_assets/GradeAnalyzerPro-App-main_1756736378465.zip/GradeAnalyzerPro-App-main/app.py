import io
import base64
import numpy as np
import pandas as pd
from flask import Flask, render_template, request, send_file, url_for
import matplotlib
matplotlib.use('Agg') # Use Agg backend for headless servers
import matplotlib.pyplot as plt # Crucial import

# --- Matplotlib Font Settings ---
# Using a generic sans-serif font as a safe default.
# This avoids errors if specific font files are not available.
# Persian characters within the plot images themselves might not render correctly
# with this setting if the default sans-serif on the server doesn't support them.
plt.rcParams['font.family'] = 'sans-serif'
plt.rcParams['font.size'] = 10 # You can adjust if needed
plt.rcParams['axes.unicode_minus'] = False # Important for correct display of minus sign

app = Flask(__name__)
app.static_folder = 'static'

# --- Download Excel Template Route ---
@app.route('/download_excel_template')
def download_excel_template():
    output = io.BytesIO()
    writer = pd.ExcelWriter(output, engine='openpyxl')
    sample_data = {
        'دانش‌آموز': [f'دانش‌آموز {i+1}' for i in range(10)],
        'سوال ۱': [18, 15, 20, 17, 16, 19, 17, 14, 19, 18],
        'سوال ۲': [16, 19, 17, 14, 18, 15, 20, 17, 16, 19],
        'سوال ۳': [19, 18, 19, 16, 17, 14, 18, 15, 20, 17],
        'سوال ۴': [17, 14, 18, 15, 19, 18, 19, 16, 17, 14],
        'سوال ۵': [20, 17, 16, 19, 17, 14, 18, 15, 19, 18],
        'نمره حداکثر سوال ۱': [20, '', '', '', '', '', '', '', '', ''],
        'نمره حداکثر سوال ۲': [20, '', '', '', '', '', '', '', '', ''],
        'نمره حداکثر سوال ۳': [20, '', '', '', '', '', '', '', '', ''],
        'نمره حداکثر سوال ۴': [20, '', '', '', '', '', '', '', '', ''],
        'نمره حداکثر سوال ۵': [20, '', '', '', '', '', '', '', '', '']
    }
    df = pd.DataFrame(sample_data)
    df.to_excel(writer, index=False, sheet_name='نمرات آزمون')
    # writer.save() was used for older pandas, writer.close() is for newer.
    # If using pandas < 1.3.0, you might need writer.save()
    try:
        writer.close() # For pandas >= 1.3.0
    except AttributeError:
        writer.save() # For older pandas versions

    output.seek(0)
    return send_file(
        output,
        download_name='score_template.xlsx',
        as_attachment=True,
        mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
    )

# --- Index Route ---
@app.route('/')
def index():
    # Pass any necessary default values or error messages if needed
    return render_template('index.html', error=request.args.get('error'))


# --- Analyze Route ---
@app.route('/analyze', methods=['POST'])
def analyze():
    num_students = 0
    num_questions = 0
    max_total_score_input = 0 # Renamed to avoid conflict with other max_total_score variables
    reliability = 0
    all_scores_by_student = []
    max_scores_per_question = []
    additional_requests = request.form.get('additional_requests', '').strip()

    form_data_for_repopulation = request.form.to_dict()


    try:
        # --- 1. Data Input: Excel or Manual ---
        if 'excel_file' in request.files and request.files['excel_file'].filename != '':
            excel_file = request.files['excel_file']
            try:
                df = pd.read_excel(excel_file)
            except Exception as e:
                raise ValueError(f"خطا در خواندن فایل اکسل: {e}")


            score_cols = [col for col in df.columns if str(col).startswith('سوال ')]
            max_score_cols = [col for col in df.columns if str(col).startswith('نمره حداکثر سوال ')]


            if not score_cols:
                raise ValueError("فایل اکسل باید شامل ستون‌هایی با نام 'سوال ۱', 'سوال ۲' و ... باشد.")
            if not max_score_cols or len(max_score_cols) != len(score_cols):
                raise ValueError("تعداد ستون‌های 'نمره حداکثر سوال' با تعداد ستون‌های 'سوال' مطابقت ندارد یا این ستون‌ها وجود ندارند. لطفاً برای هر سوال، نمره حداکثر آن را در ردیف اول ستون مربوطه وارد کنید.")

            num_questions = len(score_cols)
            num_students = len(df)
            if num_students == 0:
                raise ValueError("فایل اکسل نباید خالی باشد.")

            for index, row in df.iterrows():
                student_scores = []
                for col_idx, col in enumerate(score_cols):
                    try:
                        score = float(row[col])
                        # Validate against max score for that question if available and valid
                        current_max_q_score = float(df.loc[0, max_score_cols[col_idx]]) # Assuming max score is in first row
                        if not (0 <= score <= current_max_q_score):
                             raise ValueError(f"نمره دانش‌آموز {index+1} در {col} ({score}) خارج از محدوده مجاز (0 تا {current_max_q_score}) است.")
                        student_scores.append(score)
                    except ValueError:
                        raise ValueError(f"نمره '{row[col]}' در ستون '{col}' (ردیف {index+2} اکسل) معتبر نیست. لطفاً فقط اعداد وارد کنید.")
                    except KeyError:
                        raise ValueError(f"ستون '{col}' برای دانش آموز {index+1} یافت نشد.")
                all_scores_by_student.append(student_scores)
            
            max_scores_per_question_from_excel = []
            for col in max_score_cols:
                try:
                    # Max scores are expected in the first row of these columns
                    max_q_score = float(df.loc[0, col])
                    if max_q_score <= 0:
                        raise ValueError(f"نمره حداکثر برای '{col}' (ردیف اول اکسل) باید یک عدد مثبت باشد.")
                    max_scores_per_question_from_excel.append(max_q_score)
                except ValueError:
                    raise ValueError(f"نمره حداکثر برای '{col}' (ردیف اول اکسل) معتبر نیست. لطفاً فقط اعداد مثبت وارد کنید.")
                except KeyError:
                    raise ValueError(f"ستون نمره حداکثر '{col}' در فایل اکسل یافت نشد.")
            max_scores_per_question = max_scores_per_question_from_excel
            
            # These might still come from form, or could be derived/validated from Excel
            max_total_score_input_str = request.form.get('max_total_score', str(sum(max_scores_per_question)))
            reliability_str = request.form.get('reliability', '0')

            try:
                max_total_score_input = float(max_total_score_input_str)
                if max_total_score_input <= 0: max_total_score_input = sum(max_scores_per_question) # Fallback if invalid
            except ValueError:
                 max_total_score_input = sum(max_scores_per_question) # Fallback if invalid

            try:
                reliability = float(reliability_str)
            except ValueError:
                raise ValueError("ضریب پایایی وارد شده معتبر نیست.")


        else: # Manual input from form
            try:
                num_students = int(request.form['num_students'])
                num_questions = int(request.form['num_questions'])
                max_total_score_input = float(request.form['max_total_score'])
                reliability = float(request.form['reliability'])
            except KeyError as e:
                raise ValueError(f"فیلد ورودی '{e}' تکمیل نشده است.")
            except ValueError:
                raise ValueError("مقادیر ورودی برای تعداد دانش‌آموزان، سوالات، حداکثر نمره یا پایایی نامعتبر هستند.")

            
            for q_idx in range(1, num_questions + 1):
                max_q_score_str = request.form.get(f'max_score_q{q_idx}', '')
                if not max_q_score_str.strip():
                    raise ValueError(f"نمره حداکثر برای سوال {q_idx} وارد نشده است.")
                try:
                    max_q_score = float(max_q_score_str)
                    if max_q_score <= 0:
                        raise ValueError(f"نمره حداکثر برای سوال {q_idx} باید یک عدد مثبت باشد.")
                    max_scores_per_question.append(max_q_score)
                except ValueError:
                    raise ValueError(f"نمره حداکثر وارد شده برای سوال {q_idx} معتبر نیست. لطفاً فقط اعداد مثبت وارد کنید.")

            for s_idx in range(1, num_students + 1):
                scores_for_student = []
                for q_idx in range(1, num_questions + 1):
                    score_key = f'score_{s_idx}_{q_idx}'
                    score_str = request.form.get(score_key, '')
                    if not score_str.strip():
                        raise ValueError(f"نمره برای دانش‌آموز {s_idx}، سوال {q_idx} وارد نشده است.")
                    try:
                        score = float(score_str)
                        if not (0 <= score <= max_scores_per_question[q_idx-1]):
                            raise ValueError(f"نمره دانش‌آموز {s_idx} در سوال {q_idx} ({score}) خارج از محدوده مجاز (0 تا {max_scores_per_question[q_idx-1]}) است.")
                        scores_for_student.append(score)
                    except IndexError:
                         raise ValueError(f"عدم تطابق در تعداد نمرات حداکثر و سوالات برای دانش آموز {s_idx}, سوال {q_idx}.")
                    except ValueError: # Catches float conversion and other ValueErrors from the condition
                        raise ValueError(f"نمره وارد شده برای دانش‌آموز {s_idx}، سوال {q_idx} معتبر نیست.")
                all_scores_by_student.append(scores_for_student)
        
        if num_students <= 0 or num_questions <= 0 : # max_total_score_input checked within branches
            raise ValueError("تعداد دانش‌آموزان و تعداد سوالات باید اعداد مثبت باشند.")
        if not (0 <= reliability <= 1):
            raise ValueError("ضریب پایایی باید عددی بین 0 و 1 باشد.")
        if not all_scores_by_student:
            raise ValueError("داده‌های نمرات برای تحلیل یافت نشد.")

        scores_matrix = np.array(all_scores_by_student)
        if scores_matrix.shape != (num_students, num_questions):
            raise ValueError("ابعاد ماتریس نمرات با تعداد دانش آموزان و سوالات همخوانی ندارد.")


        # --- 2. Per-Question Analysis ---
        question_analyses = []
        for q_idx in range(num_questions):
            question_scores = scores_matrix[:, q_idx]
            # max_q_score should be from max_scores_per_question list
            if q_idx >= len(max_scores_per_question):
                raise ValueError(f"اطلاعات نمره حداکثر برای سوال {q_idx+1} موجود نیست.")
            max_q_score_for_this_q = max_scores_per_question[q_idx]
            
            q_mean = np.mean(question_scores)
            q_std_dev = np.std(question_scores)
            q_min = np.min(question_scores)
            q_max = np.max(question_scores)
            q_difficulty = (q_mean / max_q_score_for_this_q) * 100 if max_q_score_for_this_q > 0 else 0

            total_scores_for_di = np.sum(scores_matrix, axis=1)
            sorted_indices = np.argsort(total_scores_for_di)
            # Ensure num_group_students is at least 1 if num_students > 0
            num_group_students = max(1, int(np.floor(num_students * 0.27))) # Use floor and ensure at least 1
            
            di_value_num = 0.0
            di_display = "نیاز به داده بیشتر"

            if num_students >= 5 and num_group_students > 0 and (num_students - num_group_students) >= num_group_students : # Check if distinct groups can be formed
                lower_group_indices = sorted_indices[:num_group_students]
                upper_group_indices = sorted_indices[num_students - num_group_students:]
                
                # Ensure groups are not empty and indices are valid
                if lower_group_indices.size > 0 and upper_group_indices.size > 0:
                    lower_group_scores = question_scores[lower_group_indices]
                    upper_group_scores = question_scores[upper_group_indices]

                    if lower_group_scores.size > 0 and upper_group_scores.size > 0:
                        mean_upper = np.mean(upper_group_scores)
                        mean_lower = np.mean(lower_group_scores)
                        
                        if max_q_score_for_this_q > 0:
                            di_value_num = (mean_upper - mean_lower) / max_q_score_for_this_q
                            di_display = f"{di_value_num:.2f}"
                        else:
                            di_display = "نمره حداکثر سوال صفر است"
                    else:
                        di_display = "گروه خالی برای DI"
                else:
                    di_display = "ایندکس نامعتبر گروه DI"

            question_analyses.append({
                'q_num': q_idx + 1,
                'mean': f"{q_mean:.2f}", 'std_dev': f"{q_std_dev:.2f}",
                'min': f"{q_min:.2f}", 'max': f"{q_max:.2f}",
                'difficulty': f"{q_difficulty:.2f}%", 'discrimination': di_display
            })

        # --- 3. Overall Test Analysis ---
        total_scores = np.sum(scores_matrix, axis=1)
        mean_total_score = np.mean(total_scores) if total_scores.size > 0 else 0
        median_total_score = np.median(total_scores) if total_scores.size > 0 else 0
        std_dev_total_score = np.std(total_scores) if total_scores.size > 0 else 0
        min_total_score = np.min(total_scores) if total_scores.size > 0 else 0
        max_total_score_achieved = np.max(total_scores) if total_scores.size > 0 else 0
        range_total_score = max_total_score_achieved - min_total_score
        
        # Ensure reliability is between 0 and 1 before sqrt
        reliability_for_sem = max(0, min(1, reliability))
        sem_total_score = std_dev_total_score * np.sqrt(1 - reliability_for_sem) if std_dev_total_score > 0 else 0


        # --- 4. Generating Plots ---
        plot_urls = {}

        # Jawbone Plot
        if total_scores.size > 0 : # Only plot if data exists
            plt.figure(figsize=(12, 7))
            # Ensure labels and values have same length
            plot_labels = ['حداقل نمره کل', 'حداکثر نمره کل (کسب شده)', 'دامنه نمره کل', 'میانگین نمره کل', 'میانه نمره کل', 'انحراف معیار نمره کل']
            plot_values = [min_total_score, max_total_score_achieved, range_total_score, mean_total_score, median_total_score, std_dev_total_score]
            
            # Insert max possible score if it's meaningful
            if max_total_score_input > 0:
                plot_labels.insert(2, 'حداکثر نمره کل (ممکن)') # Insert at index 2
                plot_values.insert(2, max_total_score_input)


            plt.plot(plot_labels, plot_values, marker='o', linestyle='-', color=plt.get_cmap('Paired')(1), linewidth=2)
            
            # SEM bands only if sem_total_score is meaningful
            if sem_total_score > 0:
                plt.fill_between(
                    ['میانگین نمره کل'], [mean_total_score - sem_total_score], [mean_total_score + sem_total_score],
                    color=plt.get_cmap('Paired')(0), alpha=0.4, label=f'باند SEM ({sem_total_score:.2f})'
                )
                plt.fill_between(
                    ['میانه نمره کل'], [median_total_score - sem_total_score], [median_total_score + sem_total_score],
                    color=plt.get_cmap('Paired')(0), alpha=0.4
                )
                plt.legend(fontsize=8, loc='best')

            plt.title('نیمرخ نمرات کل آزمون با باندهای خطای معیار', fontsize=14) 
            plt.ylabel('مقدار نمره', fontsize=10)
            plt.grid(True, linestyle='--', alpha=0.7)
            plt.xticks(rotation=45, ha='right', fontsize=8) 
            plt.tight_layout()
            img_buffer_jawbone = io.BytesIO()
            plt.savefig(img_buffer_jawbone, format='png')
            img_buffer_jawbone.seek(0)
            plot_urls['jawbone'] = base64.b64encode(img_buffer_jawbone.read()).decode('utf-8')
            plt.close()

            # Histogram
            plt.figure(figsize=(10, 6))
            plt.hist(total_scores, bins=10, edgecolor='black', alpha=0.7, color=plt.get_cmap('Pastel1')(0))
            plt.title('هیستوگرام توزیع نمرات کل آزمون', fontsize=14)
            plt.xlabel('نمره کل', fontsize=10)
            plt.ylabel('تعداد دانش‌آموزان', fontsize=10)
            plt.grid(axis='y', alpha=0.75)
            plt.xticks(fontsize=8)
            plt.yticks(fontsize=8)
            plt.tight_layout()
            img_buffer_hist = io.BytesIO()
            plt.savefig(img_buffer_hist, format='png')
            img_buffer_hist.seek(0)
            plot_urls['histogram'] = base64.b64encode(img_buffer_hist.read()).decode('utf-8')
            plt.close()

        # --- 5. Final Analysis Text ---
        final_analysis_text = "<h3>تحلیل نهایی آزمون:</h3>"
        final_analysis_text += f"<p><strong>تعداد دانش‌آموزان:</strong> {num_students} نفر</p>"
        final_analysis_text += f"<p><strong>تعداد سوالات آزمون:</strong> {num_questions} سوال</p>"
        final_analysis_text += f"<p><strong>حداکثر نمره کل آزمون (ممکن):</strong> {max_total_score_input} </p>"
        final_analysis_text += f"<p><strong>ضریب پایایی (Reliability):</strong> {reliability:.2f}</p>"
        final_analysis_text += "<h4>تفسیر کلی نمرات آزمون:</h4>"
        final_analysis_text += f"<p>میانگین کل نمرات: <strong>{mean_total_score:.2f}</strong>, انحراف معیار: <strong>{std_dev_total_score:.2f}</strong>.</p>"
        final_analysis_text += f"<p>خطای معیار اندازه‌گیری (SEM): <strong>{sem_total_score:.2f}</strong>.</p>"
        
        # Filter questions for difficulty analysis (handle potential string if di_value was not calculated)
        difficult_q_nums = [q['q_num'] for q in question_analyses if isinstance(q.get('difficulty'), str) and float(q['difficulty'].replace('%','')) < 50]
        easy_q_nums = [q['q_num'] for q in question_analyses if isinstance(q.get('difficulty'), str) and float(q['difficulty'].replace('%','')) > 80]
        medium_q_nums = [q['q_num'] for q in question_analyses if isinstance(q.get('difficulty'), str) and 50 <= float(q['difficulty'].replace('%','')) <= 80]


        final_analysis_text += "<h4>تحلیل سختی سوالات:</h4>"
        if difficult_q_nums: final_analysis_text += f"<p><strong>دشوار:</strong> سوالات شماره {', '.join(map(str, difficult_q_nums))}</p>"
        if easy_q_nums: final_analysis_text += f"<p><strong>آسان:</strong> سوالات شماره {', '.join(map(str, easy_q_nums))}</p>"
        if medium_q_nums: final_analysis_text += f"<p><strong>متوسط:</strong> سوالات شماره {', '.join(map(str, medium_q_nums))}</p>"
        if not difficult_q_nums and not easy_q_nums and not medium_q_nums : final_analysis_text += "<p>داده کافی برای تحلیل سختی سوالات موجود نیست یا تمام سوالات خارج از این دسته‌بندی‌ها هستند.</p>"


        final_analysis_text += "<h4>تحلیل قدرت تمایز سوالات:</h4>"
        # Filter questions for discrimination analysis (handle potential string if di_value was not calculated)
        poor_d_nums = [q['q_num'] for q in question_analyses if isinstance(q.get('discrimination'), str) and q['discrimination'] not in ["نیاز به داده بیشتر", "گروه خالی برای DI", "ایندکس نامعتبر گروه DI", "نمره حداکثر سوال صفر است"] and float(q['discrimination']) < 0.2]
        good_d_nums = [q['q_num'] for q in question_analyses if isinstance(q.get('discrimination'), str) and q['discrimination'] not in ["نیاز به داده بیشتر", "گروه خالی برای DI", "ایندکس نامعتبر گروه DI", "نمره حداکثر سوال صفر است"] and float(q['discrimination']) >= 0.4]
        acceptable_d_nums = [q['q_num'] for q in question_analyses if isinstance(q.get('discrimination'), str) and q['discrimination'] not in ["نیاز به داده بیشتر", "گروه خالی برای DI", "ایندکس نامعتبر گروه DI", "نمره حداکثر سوال صفر است"] and 0.2 <= float(q['discrimination']) < 0.4]
        
        needs_more_data_d = any(q['discrimination'] in ["نیاز به داده بیشتر", "گروه خالی برای DI", "ایندکس نامعتبر گروه DI"] for q in question_analyses)

        if needs_more_data_d:
             final_analysis_text += "<p>برای محاسبه دقیق شاخص تمایز برای برخی یا تمام سوالات، نیاز به تعداد دانش‌آموزان بیشتری است یا شرایط محاسبه فراهم نبوده.</p>"
        
        if poor_d_nums: final_analysis_text += f"<p><strong>تمایز ضعیف:</strong> سوالات شماره {', '.join(map(str, poor_d_nums))}</p>"
        if acceptable_d_nums: final_analysis_text += f"<p><strong>تمایز قابل قبول:</strong> سوالات شماره {', '.join(map(str, acceptable_d_nums))}</p>"
        if good_d_nums: final_analysis_text += f"<p><strong>تمایز قوی:</strong> سوالات شماره {', '.join(map(str, good_d_nums))}</p>"
        if not poor_d_nums and not acceptable_d_nums and not good_d_nums and not needs_more_data_d:
            final_analysis_text += "<p>داده کافی برای تحلیل قدرت تمایز سوالات موجود نیست یا تمام سوالات خارج از این دسته‌بندی‌ها هستند.</p>"


        if additional_requests:
            final_analysis_text += f"<h4>درخواست‌های تحلیل افزوده:</h4><p>{additional_requests}</p><p>این درخواست‌ها در حال حاضر پیاده‌سازی نشده‌اند.</p>"

        return render_template(
            'results.html',
            question_analyses=question_analyses,
            total_scores_stats={
                'mean': f"{mean_total_score:.2f}", 'median': f"{median_total_score:.2f}",
                'std_dev': f"{std_dev_total_score:.2f}", 'min': f"{min_total_score:.2f}",
                'max': f"{max_total_score_achieved:.2f}", 'range': f"{range_total_score:.2f}",
                'sem': f"{sem_total_score:.2f}", 'max_possible': f"{max_total_score_input:.2f}"
            },
            final_analysis=final_analysis_text,
            plot_urls=plot_urls
        )

    except ValueError as e: # Catching specific errors for user feedback
        # Log the error for server-side debugging
        print(f"ValueError in /analyze: {e}")
        import traceback
        traceback.print_exc()
        # Return to index page with error and repopulate form
        return render_template('index.html', error=str(e), **form_data_for_repopulation)
    except Exception as e: # Catching any other unexpected errors
        # Log the full exception for debugging on the server
        print(f"An unexpected error occurred in /analyze: {e}")
        import traceback
        traceback.print_exc() # For more detailed server logs
        # Return to index page with generic error and repopulate form
        return render_template('index.html', error=f"یک خطای غیرمنتظره در سرور رخ داد. لطفاً بعداً دوباره امتحان کنید.", **form_data_for_repopulation)

# --- Main Execution ---
if __name__ == '__main__':
    # For production, use a production-ready WSGI server like Gunicorn
    # And set debug=False. Host and port might be set by Render.
    app.run(debug=False, host='0.0.0.0', port=int(os.environ.get('PORT', 8080)))